#pragma once
#include "types.h"

//Charlie made this file
int input_number(int min, int max);
String* input_string();
void clear_input_buffer();